from flask import Flask, render_template, request
from memcached_stats import MemcachedStats
import logging, sys


app = Flask(__name__)
logging.basicConfig(stream=sys.stderr)

mem = MemcachedStats('127.0.0.1', '11211')

@app.route('/')
def stats():
    logging.error("Sample error message")
	return render_template("app.html.j2", some_message=mem.stats())
	
	
if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)